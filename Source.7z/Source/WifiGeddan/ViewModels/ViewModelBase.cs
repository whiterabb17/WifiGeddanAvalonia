using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;

namespace WifiGeddan.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
        
    }
}
